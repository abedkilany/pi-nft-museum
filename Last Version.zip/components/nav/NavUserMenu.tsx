'use client';

import Link from 'next/link';
import { PiConnectButton } from '@/components/PiConnectButton';
import { AdminPageLink } from '@/components/auth/AdminPageLink';
import { useEffect, useRef, useState } from 'react';
import { usePathname } from 'next/navigation';
import { usePiAuth } from '@/components/auth/PiAuthProvider';

type Props = {
  user: {
    username: string;
    role: string;
  } | null;
  showAdmin: boolean;
};

export function NavUserMenu({ user, showAdmin }: Props) {
  const [open, setOpen] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const ref = useRef<HTMLDivElement | null>(null);
  const pathname = usePathname();
  const { logout } = usePiAuth();

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    function handleClick(event: MouseEvent) {
      if (!ref.current) return;
      if (!ref.current.contains(event.target as Node)) setOpen(false);
    }

    function handleEscape(event: KeyboardEvent) {
      if (event.key === 'Escape') setOpen(false);
    }

    document.addEventListener('mousedown', handleClick);
    document.addEventListener('keydown', handleEscape);

    return () => {
      document.removeEventListener('mousedown', handleClick);
      document.removeEventListener('keydown', handleEscape);
    };
  }, []);

  if (!user) {
    return (
      <div className="nav-auth">
        <PiConnectButton className="button primary nav-connect-button">
          Connect with Pi
        </PiConnectButton>
      </div>
    );
  }

  async function handleLogout() {
    if (isLoggingOut) return;
    setIsLoggingOut(true);

    try {
      await logout();
      window.location.href = '/';
    } catch (error) {
      console.error('Logout failed', error);
      alert('Logout failed. Please try again.');
      setIsLoggingOut(false);
    }
  }

  return (
    <div ref={ref} className="nav-user-menu">
      <button
        className="button secondary nav-user-trigger"
        type="button"
        onClick={() => setOpen((value) => !value)}
        aria-expanded={open}
        aria-haspopup="menu"
      >
        <span className="nav-user-trigger-desktop">My account · {user.username}</span>
        <span className="nav-user-trigger-mobile">Account</span>
      </button>

      {open ? (
        <div className="card nav-user-popover" role="menu">
          <div className="nav-user-header">
            <strong>{user.username}</strong>
            <span>{user.role}</span>
          </div>

          <div className="nav-user-links">
            <Link href={`/profile/${user.username}`} prefetch={false} className="button secondary nav-user-link">
              Profile
            </Link>
            <Link href="/account" className="button secondary nav-user-link">
              Account
            </Link>
            <Link href="/account/artworks" prefetch={false} className="button secondary nav-user-link">
              My artworks
            </Link>
            {showAdmin ? (
              <AdminPageLink className="button secondary nav-user-link">
                Admin panel
              </AdminPageLink>
            ) : null}
            <button
              className="button secondary nav-user-link"
              type="button"
              onClick={handleLogout}
              disabled={isLoggingOut}
            >
              {isLoggingOut ? 'Logging out…' : 'Logout'}
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
