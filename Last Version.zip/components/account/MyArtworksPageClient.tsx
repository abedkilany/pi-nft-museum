'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { ResubmitArtworkButton } from '@/components/account/ResubmitArtworkButton';
import { MintArtworkButton } from '@/components/account/MintArtworkButton';
import { PremiumBadge } from '@/components/shared/PremiumBadge';
import { formatDateTime, getMintWindowStatus } from '@/lib/artwork-windows';
import { getArtworkStatusLabel } from '@/lib/artwork-status';
import { DeleteArtworkButton } from '@/components/account/DeleteArtworkButton';
import { ArtworkStatusActions } from '@/components/account/ArtworkStatusActions';
import { piApiFetch } from '@/lib/pi-auth-client';
import { RequirePiAuth } from '@/components/auth/RequirePiAuth';
import { usePiAuth } from '@/components/auth/PiAuthProvider';
import { getDisplayImageUrl } from '@/lib/image-url';

export default function MyArtworksPageClient() {
  const { status } = usePiAuth();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (status !== 'authenticated') {
      return;
    }

    let cancelled = false;
    async function load() {
      const response = await piApiFetch('/api/account/artworks', { method: 'GET', cache: 'no-store' }).catch(() => null);
      const payload = response ? await response.json().catch(() => null) : null;
      if (cancelled) return;
      if (response?.status === 401) {
        setError('Please reconnect with Pi to load your artworks.');
        setLoading(false);
        return;
      }

      if (!response?.ok || !payload?.ok) {
        setError(payload?.error || 'Failed to load artworks.');
        setLoading(false);
        return;
      }
      setData(payload);
      setLoading(false);
    }
    void load();
    return () => { cancelled = true; };
  }, [status]);

  if (status !== 'authenticated') return <RequirePiAuth loadingText="Loading your artworks…" />;
  if (loading) return <div className="page-stack"><div className="card surface-section"><p>Loading artworks…</p></div></div>;
  if (error) return <div className="page-stack"><div className="card surface-section"><p>{error}</p></div></div>;

  const artworks = data?.artworks || [];
  const reviewHours = data?.reviewHours || 48;
  const archiveMessage = data?.archiveMessage || '';
  const username = data?.user?.username || null;

  return (
    <div className="page-stack">
      <div className="card surface-section">
        <div className="section-head compact">
          <div><span className="section-kicker">Artwork workflow</span><h1>My artworks</h1></div>
          <p>Private library for your own drafts, published works, premium pieces, and archived items.</p>
        </div>
        <div className="card-actions">
          <Link href="/upload" className="button primary">Upload new artwork</Link>
          <Link href={username ? `/profile/${username}` : "/account"} prefetch={false} className="button secondary">Open profile</Link>
        </div>
        {artworks.length === 0 ? <p>You have not submitted any artworks yet.</p> : (
          <div className="stack-md">
            {artworks.map((artwork: any) => {
              const mintWindowStatus = getMintWindowStatus(artwork);
              const showMintButton = mintWindowStatus === 'mint_open';
              return (
                <div key={artwork.id} className="card my-artwork-item">
                  <img src={getDisplayImageUrl(artwork.imageUrl)} alt={artwork.title} className="my-artwork-thumb" />
                  <div>
                    <div style={{ display: 'flex', gap: '10px', alignItems: 'center', flexWrap: 'wrap', marginBottom: '8px' }}><h3 style={{ margin: 0 }}>{artwork.title}</h3>{artwork.status === 'PREMIUM' ? <PremiumBadge /> : null}</div>
                    <p style={{ margin: '0 0 6px', color: 'var(--muted)' }}>Status: <strong>{getArtworkStatusLabel(artwork.status)}</strong></p>
                    <p style={{ margin: '0 0 6px', color: 'var(--muted)' }}>Category: {artwork.category?.name || 'General'}</p>
                    <p style={{ margin: '0 0 6px', color: 'var(--muted)' }}>Base price: {Number(artwork.basePrice ?? artwork.price).toFixed(2)} {artwork.currency}</p><p style={{ margin: '0 0 6px', color: 'var(--muted)' }}>Discount: {Number(artwork.discountPercent ?? 0).toFixed(2)}%</p><p style={{ margin: '0 0 10px', color: 'var(--muted)' }}>Final price: {Number(artwork.price).toFixed(2)} {artwork.currency}</p>
                    {artwork.reviewNote ? <div className="card" style={{ padding: '12px', marginBottom: '10px' }}><strong>Review note</strong><p style={{ marginBottom: 0 }}>{artwork.reviewNote}</p></div> : null}
                    {['PUBLIC_REVIEW', 'MINTING'].includes(artwork.status) ? <div className="card" style={{ padding: '12px' }}><strong>Review timeline</strong><p style={{ margin: '8px 0 4px' }}>Review started: {formatDateTime(artwork.publicReviewStartedAt)}</p><p style={{ margin: '0 0 4px' }}>Mint opens: {formatDateTime(artwork.mintWindowOpensAt)}</p><p style={{ margin: 0 }}>Mint closes: {formatDateTime(artwork.mintWindowEndsAt)}</p></div> : null}
                  </div>
                  <div className="my-artwork-actions">
                    <Link href={`/artwork/${artwork.id}`} className="button secondary">View</Link>
                    <Link href={`/account/artworks/${artwork.id}/edit`} className="button secondary">Edit</Link>
                    <ArtworkStatusActions artworkId={artwork.id} status={artwork.status} />
                    {artwork.status === 'REJECTED' ? <ResubmitArtworkButton artworkId={artwork.id} /> : null}
                    {showMintButton ? <MintArtworkButton artworkId={artwork.id} /> : null}
                    {['PUBLIC_REVIEW', 'MINTING'].includes(artwork.status) && mintWindowStatus === 'reviewing' ? <p style={{ margin: 0, fontSize: '14px', color: 'var(--muted)' }}>Mint opens after the {reviewHours}-hour public review period.</p> : null}
                    {['PUBLIC_REVIEW', 'MINTING'].includes(artwork.status) && mintWindowStatus === 'expired' ? <p style={{ margin: 0, fontSize: '14px', color: 'var(--muted)' }}>Mint window expired. This artwork will return to the configured fallback status.</p> : null}
                    {artwork.status === 'PUBLISHED' ? <Link href="/gallery" className="button primary">Open in gallery</Link> : null}
                    {artwork.status === 'PREMIUM' ? <Link href="/premium" className="button primary">Open in premium</Link> : null}
                    {artwork.status === 'ARCHIVED' ? <p style={{ margin: 0, fontSize: '13px', color: 'var(--muted)' }}>{archiveMessage}</p> : null}
                    <DeleteArtworkButton artworkId={artwork.id} title={artwork.title} archived={artwork.status === 'ARCHIVED'} />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
